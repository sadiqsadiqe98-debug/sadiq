# flutter_login_sharedprefs_mohammad_sadiq

A minimal Flutter login page that saves username and password using SharedPreferences.

**Name:** Mohammad Sadiq
**ID:** 22-RD-200-162

## How to run

1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. From this project folder run:
   - `flutter pub get`
   - `flutter run`

